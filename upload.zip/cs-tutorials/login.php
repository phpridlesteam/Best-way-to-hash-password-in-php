
<?php
/*
Author: Joshua c okorie
About:web developement tutorials and free source code 
Website: https://www.phpridles.com
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>How to  Create a PHP Password Hash Function() in PHP| PHP Ridles </title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<link rel="stylesheet" href="js/bootstrap.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<style type="text/css">
.login-form {
width: 385px;
margin: 30px auto;
}
.login-form form {        
margin-bottom: 15px;
background: #f7f7f7;
box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
padding: 30px;
}
.login-form h2 {
margin: 0 0 15px;
}
.form-control, .login-btn {
min-height: 38px;
border-radius: 2px;
}
.input-group-addon .fa {
font-size: 18px;
}
.login-btn {
font-size: 15px;
font-weight: bold;
}
.social-btn .btn {
border: none;
margin: 10px 3px 0;
opacity: 1;
}
.social-btn .btn:hover {
opacity: 0.9;
}
.social-btn .btn-primary {
background: #507cc0;
}
.social-btn .btn-info {
background: #64ccf1;
}
.social-btn .btn-danger {
background: #df4930;
}
.or-seperator {
margin-top: 20px;
text-align: center;
border-top: 1px solid #ccc;
}
.or-seperator i {
padding: 0 10px;
background: #f7f7f7;
position: relative;
top: -11px;
z-index: 1;
}   
</style>
</head>
<body>
<?php
/*
NOTICE:
I used php version 5.6+ for this tutorial
please make sure you are using at list php5.6+
or download the lastes version of wampserver it contain >php5.6
*/
?>
<div class="login-form">
<form action="login.php" method="post">
<h4 >Best Way to Hash and Retrive Hashed <center> Password in php during Login </center></h4>
<?php
session_start();
//check if session message is avaliable
if (isset($_SESSION['message'])){
//display session mesage
echo $_SESSION['message'];
}
//remove session message
unset($_SESSION['message']);
?>   
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><i class="icon-user"></i></span>
<input type="text" class="form-control" name="username" placeholder="Username" required="required">       
</div>
</div>
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><i class="icon-lock"></i></span>
<input type="password" class="form-control" name="password" placeholder="Password" required="required">       
</div>
</div>        
<div class="form-group">
<button type="submit" name="login"class="btn btn-primary login-btn btn-block">Sign in</button>
</div>

<div class="or-seperator"><i>or</i></div>
<div class="text-center social-btn">
<a href="index.php" class="btn btn-primary"><i class="icon-signin"></i>&nbsp;signup</a>

</div>
</form>
</div>
<?php
//code to sanitize and clean up user input
function sanitizeString($var)
{
//remove slashe
$var = stripslashes($var);
//remove tags
$var = strip_tags($var);
//remove htmlentities
$var = htmlentities($var);
//return a clean value for storage
return $var;
}
?>

<?php

if (isset($_POST['login']))
{
$conn = mysqli_connect("localhost","root","","user_table");
// Check connection if there is error in connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$username =sanitizeString($_POST['username']);
$password = ($_POST['password']);
/* user */
$query = "SELECT * FROM user_table WHERE username='$username'";
$result = mysqli_query($conn,$query);
$num_row = mysqli_num_rows($result);
if($num_row==1)
{
$getdata=mysqli_fetch_array($result);
$hashed_password = $getdata['password'];
if ( password_verify ( $password , $hashed_password ))
{
/* future proof the password */
if ( password_needs_rehash($hashed_password , PASSWORD_DEFAULT)) {
/* recreate the hash */
$rehashed_password = password_hash($password, PASSWORD_DEFAULT );
/* store the rehashed password in MySQL */
}

//prepare session variables
$getdata=mysqli_fetch_array($result);
$_SESSION['username']= $username;
//redirect to a success page
header('location:success.php');
}
}
else{
//if there is no user of such redirect back to login page and display warning message
header('location:login.php');
$_SESSION['message']='<div class=" alert-warning">Invalid login details!</font></div>';
}
}
?>
</body>
</html>                            
