<?php
	session_start();
	//checking if session data are avaliable if not return to login page
	if (!isset($_SESSION['username']) ||(trim ($_SESSION['username']) =='')) {
		header('location:login.php');
		exit();
	}
	//database connections
	
 $conn = mysqli_connect("localhost","root","","user_table");
// Check connection if there is error in connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
	//query database to get users data
	$query=mysqli_query($conn,"select * from user_table where username='".$_SESSION['username']."'");
	$row=mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PHP password hash funtion()</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<link rel="stylesheet" href="js/bootstrap.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<style type="text/css">
  .login-form {
    width: 385px;
    margin: 30px auto;
  }
    .login-form form {        
      margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .login-btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .input-group-addon .fa {
        font-size: 18px;
    }
    .login-btn {
        font-size: 15px;
        font-weight: bold;
    }
  .social-btn .btn {
    border: none;
        margin: 10px 3px 0;
        opacity: 1;
  }
    .social-btn .btn:hover {
        opacity: 0.9;
    }
  .social-btn .btn-primary {
        background: #507cc0;
    }
  .social-btn .btn-info {
    background: #64ccf1;
  }
  .social-btn .btn-danger {
    background: #df4930;
  }
    .or-seperator {
        margin-top: 20px;
        text-align: center;
        border-top: 1px solid #ccc;
    }
    .or-seperator i {
        padding: 0 10px;
        background: #f7f7f7;
        position: relative;
        top: -11px;
        z-index: 1;
    }   
</style>
</head>
<body>
    
		<div class="login-form">
			<form action="#" method="post">
					<h2 class="text-center">Login Success</h2>
					<div class="div_con">
					You are Welcome <?php echo $row['username']; ?>
					<br><br><br>
					<a href="logout" class="btn_login">logout</a></center>
					</div>
			</form>
		</div>
</body>
</html>
