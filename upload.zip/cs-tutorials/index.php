
<?php
/*
Author: Joshua c okorie
About:web developement tutorials
Website: https://www.phpridles.com
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PHP password hash funtion()</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<link rel="stylesheet" href="js/bootstrap.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<style type="text/css">

  .login-form {
    width: 385px;
    margin: 30px auto;
  }
    .login-form form {        
      margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .login-btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .input-group-addon .fa {
        font-size: 18px;
    }
    .login-btn {
        font-size: 15px;
        font-weight: bold;
    }
  .social-btn .btn {
    border: none;
        margin: 10px 3px 0;
        opacity: 1;
  }
    .social-btn .btn:hover {
        opacity: 0.9;
    }
  .social-btn .btn-primary {
        background: #507cc0;
    }
  .social-btn .btn-info {
    background: #64ccf1;
  }
  .social-btn .btn-danger {
    background: #df4930;
  }
    .or-seperator {
        margin-top: 20px;
        text-align: center;
        border-top: 1px solid #ccc;
    }
    .or-seperator i {
        padding: 0 10px;
        background: #f7f7f7;
        position: relative;
        top: -11px;
        z-index: 1;
    }   
    .form-inline {
        display: inline-block;
    }
  .navbar-header.col {
    padding: 0 !important;
  } 
  .navbar {   
    background: #fff;
    padding-left: 16px;
    padding-right: 16px;
    border-bottom: 1px solid #d6d6d6;
    box-shadow: 0 0 4px rgba(0,0,0,.1);
  }
  .nav-link img {
    border-radius: 50%;
    width: 36px;
    height: 36px;
    margin: -8px 0;
    float: left;
    margin-right: 10px;
  }
  .navbar .navbar-brand {
    color: #555;
    padding-left: 0;
    padding-right: 50px;
    font-family: 'Merienda One', sans-serif;
  }
  .navbar .navbar-brand i {
    font-size: 20px;
    margin-right: 5px;
  }
  .search-box {
        position: relative;
    } 
    .search-box input {
    box-shadow: none;
        padding-right: 35px;
        border-radius: 3px !important;
    }
  .search-box .input-group-addon {
        min-width: 35px;
        border: none;
        background: transparent;
        position: absolute;
        right: 0;
        z-index: 9;
        padding: 7px;
    height: 100%;
    }
    .search-box i {
        color: #a0a5b1;
    font-size: 19px;
    }
  .navbar .nav-item i {
    font-size: 18px;
  }
  .navbar .dropdown-item i {
    font-size: 16px;
    min-width: 22px;
  }
  .navbar .nav-item.open > a {
    background: none !important;
  }
  .navbar .dropdown-menu {
    border-radius: 1px;
    border-color: #e5e5e5;
    box-shadow: 0 2px 8px rgba(0,0,0,.05);
  }
  .navbar .dropdown-menu li a {
    color: #777;
    padding: 8px 20px;
    line-height: normal;
  }
  .navbar .dropdown-menu li a:hover, .navbar .dropdown-menu li a:active {
    color: #333;
  } 
  .navbar .dropdown-item .material-icons {
    font-size: 21px;
    line-height: 16px;
    vertical-align: middle;
    margin-top: -2px;
  }
  .navbar .badge {
    background: #f44336;
    font-size: 11px;
    border-radius: 20px;
    position: absolute;
    min-width: 10px;
    padding: 4px 6px 0;
    min-height: 18px;
    top: 5px;
  }
  .navbar ul.nav li a.notifications, .navbar ul.nav li a.messages {
    position: relative;
    margin-right: 10px;
  }
  .navbar ul.nav li a.messages {
    margin-right: 20px;
  }
  .navbar a.notifications .badge {
    margin-left: -8px;
  }
  .navbar a.messages .badge {
    margin-left: -4px;
  } 
  .navbar .active a, .navbar .active a:hover, .navbar .active a:focus {
    background: transparent !important;
  }
  @media (min-width: 1200px){
    .form-inline .input-group {
      width: 300px;
      margin-left: 30px;
    }
  }
  @media (max-width: 1199px){
    .form-inline {
      display: block;
      margin-bottom: 10px;
    }
    .input-group {
      width: 100%;
    }
  }
</style>
</head>
<body>
    <?php
/*
NOTICE:
I used php version 5.6+ for this tutorial
please make sure you are using at list php5.6+
or download the lastes version of wampserver it contain >php5.6
*/
?>
<nav class="navbar navbar-default navbar-expand-xl navbar-light">
  <div class="navbar-header d-flex col">
    <a class="navbar-brand" href="#"><i class="fa fa-cube"></i>Brand<b>Name</b></a>     
    <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
      <span class="navbar-toggler-icon"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  <!-- Collection of nav links, forms, and other content for toggling -->
  <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
    <ul class="nav navbar-nav">
      <li class="nav-item active"><a href="#" class="nav-link">Home</a></li>
      <li class="nav-item"><a href="#" class="nav-link">About</a></li>
      <li class="nav-item dropdown">
        <a data-toggle="dropdown" class="nav-link dropdown-toggle" href="#">Services <b class="caret"></b></a>
        <ul class="dropdown-menu">          
          <li><a href="#" class="dropdown-item">Web Design</a></li>
          <li><a href="#" class="dropdown-item">Web Development</a></li>
          <li><a href="#" class="dropdown-item">Graphic Design</a></li>
          <li><a href="#" class="dropdown-item">Digital Marketing</a></li>
        </ul>
      </li>
      <li class="nav-item"><a href="#" class="nav-link">Blog</a></li>
      <li class="nav-item"><a href="#" class="nav-link">Contact</a></li>
    </ul>
    <form class="navbar-form form-inline">
      <div class="input-group search-box">                
        <input type="text" id="search" class="form-control" placeholder="Search by Name">
        <span class="input-group-addon"><i class="material-icons">&#xE8B6;</i></span>
      </div>
    </form>
    <ul class="nav navbar-nav navbar-right ml-auto">
      <li class="nav-item"><a href="#" class="nav-link notifications"><i class="fa fa-bell-o"></i><span class="badge">1</span></a></li>
      <li class="nav-item"><a href="#" class="nav-link messages"><i class="fa fa-envelope-o"></i><span class="badge">10</span></a></li>
      <li class="nav-item dropdown">
        <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle user-action"><img src="https://www.tutorialrepublic.com/examples/images/avatar/2.jpg" class="avatar" alt="Avatar"> Paula Wilson <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a href="#" class="dropdown-item"><i class="fa fa-user-o"></i> Profile</a></li>
          <li><a href="#" class="dropdown-item"><i class="fa fa-calendar-o"></i> Calendar</a></li>
          <li><a href="#" class="dropdown-item"><i class="fa fa-sliders"></i> Settings</a></li>
          <li class="divider dropdown-divider"></li>
          <li><a href="#" class="dropdown-item"><i class="material-icons">&#xE8AC;</i> Logout</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>
<div class="login-form">
    <form action="index.php" method="post">
        <h4 class="text-center">Register user with php password hash function()</h4>   
        <div class="form-group">
          <div class="input-group">
                <span class="input-group-addon"><i class="icon-user"></i></span>
                <input type="text" class="form-control" name="username" placeholder="Username" required="required">       
            </div>
        </div>
         <div class="form-group">
          <div class="input-group">
                <span class="input-group-addon"><i class="icon-envelope"></i></span>
                <input type="text" class="form-control" name="email" placeholder="email address" required="required">       
            </div>
        </div>
    <div class="form-group">
            <div class="input-group">
                <span class="input-group-addon"><i class="icon-lock"></i></span>
                <input type="password" class="form-control" name="password" placeholder="Password" required="required">       
            </div>
        </div>        
        <div class="form-group">
            <button type="submit" name="signup"class="btn btn-primary login-btn btn-block">Register</button>
        </div>
        
    <div class="or-seperator"><i>or</i></div>
        <p class="text-center">Login  here</p>
        <div class="text-center social-btn">
            <a href="login.php" class="btn btn-primary">&nbsp; Login</a>
           
        </div>
    </form>
</div>
<?php
//code to sanitize and clean up user input
function sanitizeString($var)
{
//remove slashe
$var = stripslashes($var);
//remove tags
$var = strip_tags($var);
//remove htmlentities
$var = htmlentities($var);
//return a clean value for storage
return $var;
}
?>


<?php
if(isset($_POST['signup'])){
session_start();
//connecting to mysqlite Database
$conn = mysqli_connect("localhost","root","","user_table");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
//collecting and sanitize user's input
$username =sanitizeString($_POST['username']);
$password =sanitizeString($_POST['password']);
$email = sanitizeString($_POST['email']);
$date =date("Y-m-d H:i:s");
// performing a query to know if User already existed before creating a new User
$query=mysqli_query($conn,"select * from `user_table` where username='$username'");
if (mysqli_num_rows($query)>0 ){
// notify the user about Error! and reload the page
echo '
<div class=" alert-warning">User Registration Filed! User already existed</font></div>
';
}
else{
  //invoke a php function to to hash password
     $token = password_hash("$password", PASSWORD_DEFAULT);
//register new user if there is no such user found in the database
$query=mysqli_query($conn,"insert into user_table (username,email,password,date_of_reg) values ('$username','$email','$token','$date')");
//alert message
//
$_SESSION['message']='<div class=" alert-warning">Signup sucessful '.$username.' you can login !</font></div>';
//redirect user to login page
 echo '

  <script>
  setTimeout(
  function (){
  window.location="login.php";
  },0);
  </script> ';
  }

}
?>
</body>
</html>                            
